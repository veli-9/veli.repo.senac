<h1>Início</h1>
<br>
<h1>
    <a href="/listaaluno.php">
        Lista de alunos
    </a>
</h1>